#!/bin/bash
set -e
python3 ./fileio_conjgrad.py > output

