#!/bin/bash
set -e
python3 ./fileio_bfgs.py > output

