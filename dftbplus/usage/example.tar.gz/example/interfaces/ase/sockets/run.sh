#!/bin/bash
set -e
python3 ./socket_bfgs.py > output
