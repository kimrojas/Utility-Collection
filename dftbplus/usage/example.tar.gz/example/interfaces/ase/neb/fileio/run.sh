#!/bin/bash
set -e
python3 ./neb_fileio.py > output

