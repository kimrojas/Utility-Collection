#!/bin/bash
set -e
python3 ./pyapi.py > output

