#!/bin/bash
set -e
python3 ./pyapiQdepextpot.py > output

