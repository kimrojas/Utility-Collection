#!/bin/bash
set -e
python3 ./pyapiExtpot.py > output

