#!/bin/bash
set -e
dftb+ > output
waveplot >> output
