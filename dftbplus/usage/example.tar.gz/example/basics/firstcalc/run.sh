#!/bin/bash
set -e
dftb+ > output
