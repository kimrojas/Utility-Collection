repeatgen geo.gen 1 1 4 > geo.114.gen
gen2xyz geo.114.gen
jmol geo.114.xyz &

