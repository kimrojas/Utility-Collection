grep "Fermi level" perfect_density/detailed.out
plotxy perfect_density/dos.dat vacancy1_density/dos.dat vacancy2_density/dos.dat &
