jmol -L -s showdeflev2.js &
