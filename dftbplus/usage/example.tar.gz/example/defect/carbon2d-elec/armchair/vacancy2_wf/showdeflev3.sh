jmol -L -s showdeflev3.js &
