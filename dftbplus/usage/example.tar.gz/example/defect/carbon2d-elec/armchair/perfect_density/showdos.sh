grep "Fermi level" detailed.out
plotxy --xlabel "Energy [eV]" --ylabel "DOS" dos.dat &
